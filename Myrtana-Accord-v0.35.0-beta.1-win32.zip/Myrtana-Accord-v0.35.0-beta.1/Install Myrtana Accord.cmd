@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell.exe -Verb RunAs -ArgumentList '-NoProfile -ExecutionPolicy Bypass -File ""%~dp0scripts\g3coop_setup_gui.ps1""'"
if errorlevel 1 (
  echo Could not start the installer. Right-click this file and choose Run as administrator.
  pause
)
