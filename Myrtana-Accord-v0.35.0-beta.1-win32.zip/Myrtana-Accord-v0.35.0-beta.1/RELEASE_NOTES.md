# Myrtana Accord v0.35.0-beta.1

Cooperative Mode for Gothic 3.

Created by **Yevh**.

Contact: **yevhsec1@gmail.com**

## What you can test

- Host a new campaign or continue an old one.
- Join or rejoin a friend's campaign.
- See and fight beside other players.
- Share NPC, corpse, loot, quest, reputation, and campaign state.
- Save, reconnect, and continue later.

## Test result

We installed this build on separate Gothic 3 1.75 copies. Multiple game clients
launched, connected, entered the game, and closed without recorded
debugger faults. All 38 automated tests passed on macOS and Windows.

## Open beta limits

This build still needs more player testing for:

- Teammate death and revival.
- Unique treasure after reconnecting.
- A full cooperative combat, quest, reconnect, save, and reload session.

Back up important saves before testing.

Every player must use version `0.35.0-beta.1`.
