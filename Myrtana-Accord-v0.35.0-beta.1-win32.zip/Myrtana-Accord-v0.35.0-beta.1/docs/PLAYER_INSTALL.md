# Install Myrtana Accord

Myrtana Accord is a cooperative mode for Gothic 3 by Yevh.

You need Windows and a legal copy of Gothic 3.

1. Download the ZIP from the [release page](https://github.com/yevh/Gothic3/releases/tag/v0.35.0-beta.1).
2. Install Gothic 3 and launch it once.
3. Extract the whole Myrtana Accord ZIP into a new folder.
4. Run `Install Myrtana Accord.cmd` as administrator.
5. Finish setup.
6. Open **Myrtana Accord** from the desktop.

The host selects **New campaign** or **Continue campaign**. Friends select
**Join / rejoin friends** and enter the host address or join code.

Keep the ZIP until installation is complete. The installer keeps your existing
Myrtana Accord identity and campaign settings during normal updates.

Back up important saves before testing this beta.

For help, contact **Yevh** at **yevhsec1@gmail.com**.
