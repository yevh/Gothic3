# Play over the internet

Myrtana Accord uses UDP port `33123`.

## Tailscale

This is the easiest option.

1. Every player installs Tailscale.
2. The host shares access to their Tailscale network.
3. The host starts a campaign in the Myrtana Accord launcher.
4. Friends enter the host's `100.x.y.z` address or join code.

The installer can install Tailscale for you.

## Local network or another VPN

You can also use a local network, Radmin VPN, Hamachi, or ZeroTier. Enter the
host's local or VPN address in the launcher.

## Port forwarding

The host can forward UDP port `33123` to their PC. Use a session password when
the server is open to the internet.

## Connection problems

- Check that the host server is running.
- Check the host address.
- Check that every player is connected to the same VPN.
- Allow Myrtana Accord through Windows Firewall.
- Make sure every player uses the same mod version.

For help, contact **Yevh** at **yevhsec1@gmail.com**.
