# Myrtana Accord

Cooperative Mode for Gothic 3.

- **Version:** `v0.35.0-beta.1`
- **Created by:** Yevh
- **Contact:** yevhsec1@gmail.com

## Install

You need Windows and a legal copy of Gothic 3.

1. Extract the whole ZIP into a new folder.
2. Run `Install Myrtana Accord.cmd` as administrator.
3. Finish setup.
4. Open **Myrtana Accord** from the desktop.

The host selects **New campaign** or **Continue campaign**. Friends select
**Join / rejoin friends** and enter the host address or join code.

Read `docs/PLAYER_INSTALL.md` for more help. Read `docs/INTERNET_PLAY.md` when
playing through the internet.

This is an open beta. Back up important saves before testing.

Public release: https://github.com/yevh/Gothic3/releases/tag/v0.35.0-beta.1

## Support

- **BTC:** `bc1q5hwjrdrdwdzx409jxzhwzq5nkws6sale246wde`
- **ETH:** `0x4357FbA55494d10a3AC564A6BecaB6387a723a0B`
- **USDT (TRON network):** `TVd1jehNaGt2YwL3rNiK5VzZbx1CGvRAa8`
