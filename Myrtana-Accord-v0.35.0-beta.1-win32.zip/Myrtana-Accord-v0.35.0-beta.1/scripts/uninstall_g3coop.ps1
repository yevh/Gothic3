# Removes everything g3coop installed into a Gothic 3 directory and restores
# backed-up settings (Wave 5 rollback tool). Leaves CP/PUP untouched - those
# have their own uninstallers. Safe to run repeatedly.

param(
    [Parameter(Mandatory=$true)] [string] $GameDir,
    [switch] $KeepConfig   # keep Ini\g3coop.ini (preserves player_guid)
)

$ErrorActionPreference = "Stop"
$removed = @()

$langFiles = @(Get-ChildItem (Join-Path $GameDir "Ini") -Filter "g3coop_lang_*.ini" -ErrorAction SilentlyContinue |
    ForEach-Object { "Ini\" + $_.Name })
foreach ($rel in (@("scripts\Script_G3Coop.dll", "g3coop_server.exe", "g3coopctl.exe",
                   "g3coop.log", "g3coop_guids.txt", "g3coop_markers.json",
                   "Ini\g3coop_tuning.ini", "Ini\g3coop_quests.txt") + $langFiles)) {
    $p = Join-Path $GameDir $rel
    if (Test-Path $p) { Remove-Item $p -Force; $removed += $rel }
}
if (-not $KeepConfig) {
    $cfg = Join-Path $GameDir "Ini\g3coop.ini"
    if (Test-Path $cfg) { Remove-Item $cfg -Force; $removed += "Ini\g3coop.ini" }
}

# Restore graphics preset backup if one exists.
$iniBackup = Join-Path $GameDir "Ini\ge3.INI.g3coop-backup"
if (Test-Path $iniBackup) {
    Copy-Item $iniBackup (Join-Path $GameDir "Ini\ge3.INI") -Force
    Remove-Item $iniBackup -Force
    $removed += "(ge3.INI restored from backup)"
}

# Remove DXVK only when OUR marker proves we installed it - a bare
# d3d9.dll may be the player's own ReShade/ENB wrapper.
$dxvk = Join-Path $GameDir "d3d9.dll"
if ((Test-Path $dxvk) -and (Test-Path "$dxvk.g3coop-dxvk")) {
    Remove-Item $dxvk, "$dxvk.g3coop-dxvk" -Force; $removed += "d3d9.dll (DXVK)"
}
foreach ($shortcutName in @('Myrtana Accord.lnk','G3Coop Launcher.lnk')) {
    $shortcut = Join-Path ([Environment]::GetFolderPath("Desktop")) $shortcutName
    if (Test-Path $shortcut) { Remove-Item $shortcut -Force; $removed += $shortcutName }
}
foreach ($launcherName in @('MyrtanaAccordLauncher','G3CoopLauncher')) {
    $launcher = Join-Path $GameDir $launcherName
    if (Test-Path $launcher) { Remove-Item $launcher -Recurse -Force; $removed += $launcherName }
}
foreach ($commandName in @('Play Myrtana Accord.cmd','Co-op Setup.cmd')) {
    $command = Join-Path $GameDir $commandName
    if (Test-Path $command) { Remove-Item $command -Force; $removed += $commandName }
}

if ($removed.Count -eq 0) { Write-Host "Nothing to remove - g3coop not installed here." }
else { $removed | ForEach-Object { Write-Host "removed: $_" }; Write-Host "g3coop uninstalled." -ForegroundColor Green }
