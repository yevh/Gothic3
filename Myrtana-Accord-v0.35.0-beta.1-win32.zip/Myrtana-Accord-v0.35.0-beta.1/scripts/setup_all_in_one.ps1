# One-shot Myrtana Accord player setup: from a clean Steam Gothic 3 to
# "click Play with friends". Downloads and installs the Community
# Patch 1.75.14 and Parallel Universe Patch 1.1.1 from their official
# sources (nothing redistributed), installs the g3coop files shipped next
# to this script, optionally sets up Tailscale for internet play, and drops
# a launcher shortcut. Every step is skipped automatically when already
# done, so re-running is always safe.
#
# Usage (from an extracted g3coop release folder, as admin):
#   powershell -ExecutionPolicy Bypass -File scripts\setup_all_in_one.ps1
#   [-GameDir <path>] [-SkipVpn] [-SkipGraphics] [-Language en|ru|de|pl|fr|it|es]

param(
    [string] $GameDir = "",
    [switch] $SkipVpn,
    [switch] $SkipGraphics,          # graphics preset applies by DEFAULT (reversible)
    # Official Gothic 3 localizations (CP 1.75 international set).
    [ValidateSet("en", "ru", "de", "pl", "fr", "it", "es")] [string] $Language = "en"
)

. (Join-Path $PSScriptRoot "lib\common.ps1")

$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
$work = Join-Path $env:TEMP "g3coop_setup"
New-Item -ItemType Directory -Path $work -Force | Out-Null

# --- 1. Locate the Steam Gothic 3 install -------------------------------
Step "Locating Gothic 3"
if (-not $GameDir) {
    $steam = (Get-ItemProperty "HKLM:\SOFTWARE\WOW6432Node\Valve\Steam" -ErrorAction SilentlyContinue).InstallPath
    if ($steam) { $GameDir = Join-Path $steam "steamapps\common\Gothic 3" }
}
if (-not $GameDir -or -not (Test-Path (Join-Path $GameDir "Gothic3.exe") -ErrorAction SilentlyContinue)) {
    throw "Gothic 3 not found. Install it via Steam first, or pass -GameDir 'C:\...\Gothic 3'."
}
Write-Host "Found: $GameDir"

# --- 2. Community Patch 1.75.14 ------------------------------------------
Step "Community Patch 1.75.14"
$exeVersion = (Get-Item (Join-Path $GameDir "Gothic3.exe")).VersionInfo.FileVersion
if ($exeVersion -match "^1[,.] ?75") {
    Write-Host "Already installed ($exeVersion) - skipping."
} else {
    # CP installer needs the retail registry key or it aborts silent
    # installs on Steam copies.
    New-Item -Path "HKLM:\SOFTWARE\WOW6432Node\JoWooD Productions Software AG\Gothic III" -Force | Out-Null
    Set-ItemProperty -Path "HKLM:\SOFTWARE\WOW6432Node\JoWooD Productions Software AG\Gothic III" `
        -Name "INSTALL_DIR" -Value "$GameDir\"
    $cp = Join-Path $work "Gothic_3_EE_Patch_v1.75.14_Int_Full.exe"
    if (-not (Test-Path $cp) -or (Get-Item $cp).Length -lt 1500000000) {
        Write-Host "Downloading CP 1.75.14 (1.5 GB, one time)..."
        Get-VerifiedDownload "https://www.worldofgothic.de/download.php?id=1283" $cp
    }
    Write-Host "Installing (silent, several minutes)..."
    $p = Start-Process $cp -ArgumentList "/VERYSILENT /SUPPRESSMSGBOXES /NORESTART" -Wait -PassThru
    if ($p.ExitCode -ne 0) { throw "CP installer exited with $($p.ExitCode)" }
    Write-Host "CP 1.75.14 installed."
}

# --- 3. Parallel Universe Patch 1.1.1 ------------------------------------
Step "Parallel Universe Patch 1.1.1"
if (Test-Path (Join-Path $GameDir "scripts\Script_paru.dll")) {
    Write-Host "Already installed - skipping."
} else {
    $pup = Join-Path $work "Gothic_3_Parallel_Universe_Patch_v1.1.1.exe"
    Get-VerifiedDownload "https://cloud.georgeto.de/public.php/dav/files/AL67WFjzqzcFi7k/Gothic_3_Parallel_Universe_Patch_v1.1.1.exe" $pup `
        -Sha256 "B743676EC138811BE9C3BDA78A4BF5C38EB1C0F3E6E24479C8953CB8E6B2187D"
    $p = Start-Process $pup -ArgumentList "/VERYSILENT /SUPPRESSMSGBOXES /NORESTART" -Wait -PassThru
    if ($p.ExitCode -ne 0) { throw "PUP installer exited with $($p.ExitCode)" }
    Write-Host "PUP 1.1.1 installed."
}

# --- 4. g3coop mod files --------------------------------------------------
Step "Myrtana Accord"
$payload = @{
    "Script_G3Coop.dll" = Join-Path $GameDir "scripts\Script_G3Coop.dll"
    "g3coop_server.exe" = Join-Path $GameDir "g3coop_server.exe"
    "g3coopctl.exe"     = Join-Path $GameDir "g3coopctl.exe"
}
foreach ($name in $payload.Keys) {
    $sourceFile = Get-ChildItem -Path $root -Recurse -Filter $name | Select-Object -First 1
    if ($sourceFile) { Copy-Item $sourceFile.FullName $payload[$name] -Force; Write-Host "installed $name" }
    else { Write-Warning "$name not found in the release package (build it or re-download the release)" }
}
$iniDir = Join-Path $GameDir "Ini"
New-Item -ItemType Directory -Path $iniDir -Force | Out-Null
if (-not (Test-Path (Join-Path $iniDir "g3coop.ini"))) {
    Copy-Item (Join-Path $root "config\g3coop.example.toml") (Join-Path $iniDir "g3coop.ini")
    Write-Host "installed default Ini\g3coop.ini"
}
$questPolicy = Join-Path $iniDir 'g3coop_quests.txt'
if (-not (Test-Path $questPolicy)) {
    Copy-Item (Join-Path $root 'config\g3coop_quests.example.txt') $questPolicy
    Write-Host 'installed default Ini\g3coop_quests.txt'
}
$tuning = Join-Path $iniDir 'g3coop_tuning.ini'
if (-not (Test-Path $tuning)) {
    Copy-Item (Join-Path $root 'config\g3coop_tuning.example.ini') $tuning
    Write-Host 'installed default Ini\g3coop_tuning.ini'
}
Copy-LangCatalogs $root $iniDir
Write-Host "installed mod language catalogs (en/ru/de/pl/fr/it/es)"
$launcherDir = Join-Path $GameDir 'MyrtanaAccordLauncher'
New-Item -ItemType Directory -Path (Join-Path $launcherDir 'lib') -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $launcherDir 'assets') -Force | Out-Null
Copy-Item (Join-Path $PSScriptRoot 'g3coop_launcher.ps1') $launcherDir -Force
foreach ($helper in @('common.ps1','campaign_server.ps1')) {
    Copy-Item (Join-Path $PSScriptRoot "lib\$helper") (Join-Path $launcherDir 'lib') -Force
}
$brandImage = Join-Path $root 'assets\branding\myrtana-accord-background.jpg'
if (!(Test-Path $brandImage -PathType Leaf)) { throw "Missing Myrtana Accord artwork: $brandImage" }
Copy-Item $brandImage (Join-Path $launcherDir 'assets') -Force
if ($Language -ne "en") {
    $cfg = Join-Path $iniDir "g3coop.ini"
    Set-IniKeys $cfg @{ language = "`"$Language`"" }
    Write-Host "mod language set to $Language"
    Write-Host "GAME text/voice in Russian: use the official 1C/Snowball localization -"
    Write-Host "Steam: right-click Gothic 3 -> Properties -> Language -> Russian (text),"
    Write-Host "voice requires owning the Russian audio (Snowball edition / GOG language pack)."
}
if (-not $SkipGraphics) {
    & (Join-Path $PSScriptRoot "apply_graphics_preset.ps1") -GameDir $GameDir
    Write-Host "graphics preset applied (revert: apply_graphics_preset.ps1 -Restore)"
}

# --- 5. VPN for internet play (Tailscale) --------------------------------
if (-not $SkipVpn) {
    Step "Internet play (Tailscale)"
    $haveVpn = (Get-Command tailscale -ErrorAction SilentlyContinue) -or
               (Test-Path "$env:ProgramFiles\Tailscale\tailscale.exe") -or
               (Get-Process -Name hamachi-2* -ErrorAction SilentlyContinue) -or
               (Test-Path "${env:ProgramFiles(x86)}\Radmin VPN")
    if ($haveVpn) {
        Write-Host "A VPN client is already present - skipping."
    } else {
        $ts = Join-Path $work "tailscale-setup.exe"
        Write-Host "Downloading Tailscale..."
        Get-VerifiedDownload "https://pkgs.tailscale.com/stable/tailscale-setup-latest.exe" $ts
        Start-Process $ts -ArgumentList "/quiet" -Wait
        Write-Host "Tailscale installed. Sign in once (all players join one tailnet),"
        Write-Host "then use your 100.x address to host/join (docs/INTERNET_PLAY.md)."
    }
}

# --- 6. Launcher shortcut + final check ----------------------------------
Step "Finishing"
$desktop = [Environment]::GetFolderPath("Desktop")
if (-not $desktop) { $desktop = Join-Path $env:USERPROFILE 'Desktop' }
New-Item -ItemType Directory -Path $desktop -Force | Out-Null
$shell = New-Object -ComObject WScript.Shell
$link = $shell.CreateShortcut((Join-Path $desktop "Myrtana Accord.lnk"))
$link.TargetPath = "powershell.exe"
$link.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$(Join-Path $launcherDir 'g3coop_launcher.ps1')`" -GameDir `"$GameDir`""
$link.Save()
$legacyShortcut = Join-Path $desktop 'G3Coop Launcher.lnk'
if (Test-Path $legacyShortcut) { Remove-Item $legacyShortcut -Force }
& (Join-Path $PSScriptRoot "verify_gothic3_install.ps1") -GameDir $GameDir
Write-Host "`nAll set. Double-click 'Myrtana Accord' on the desktop, enter the" -ForegroundColor Green
Write-Host "host's IP (Tailscale 100.x for internet), your player name, and Play." -ForegroundColor Green
