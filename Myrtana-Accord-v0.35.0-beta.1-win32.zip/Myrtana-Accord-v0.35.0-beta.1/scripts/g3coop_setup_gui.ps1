# Myrtana Accord player setup.
# Shows the install choices before starting setup_all_in_one.ps1.

Add-Type -AssemblyName System.Windows.Forms, System.Drawing | Out-Null
Add-Type -Name Native -Namespace MyrtanaSetup -MemberDefinition @'
[DllImport("user32.dll")]
public static extern bool SetProcessDPIAware();
'@
[MyrtanaSetup.Native]::SetProcessDPIAware() | Out-Null
[Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference = 'Stop'

$dpiGraphics = [Drawing.Graphics]::FromHwnd([IntPtr]::Zero)
try { $dpiScale = [Math]::Max(1.0, $dpiGraphics.DpiX / 96.0) }
finally { $dpiGraphics.Dispose() }
function New-SetupFont([string]$family, [single]$points, [Drawing.FontStyle]$style = [Drawing.FontStyle]::Regular) {
    New-Object Drawing.Font($family, ($points / $dpiScale), $style)
}

$cBg = [Drawing.Color]::FromArgb(18, 20, 23)
$cCard = [Drawing.Color]::FromArgb(31, 35, 39)
$cCardHi = [Drawing.Color]::FromArgb(43, 48, 53)
$cText = [Drawing.Color]::FromArgb(235, 236, 240)
$cMuted = [Drawing.Color]::FromArgb(168, 174, 181)
$cAccent = [Drawing.Color]::FromArgb(210, 174, 108)
$cAccentHi = [Drawing.Color]::FromArgb(232, 198, 135)
$cGood = [Drawing.Color]::FromArgb(110, 231, 183)
$cBad = [Drawing.Color]::FromArgb(248, 113, 113)

$fTitle = New-SetupFont 'Segoe UI Semibold' 20
$fHeading = New-SetupFont 'Segoe UI Semibold' 11
$fBody = New-SetupFont 'Segoe UI' 9
$fSmall = New-SetupFont 'Segoe UI' 8
$fButton = New-SetupFont 'Segoe UI Semibold' 10
$fLog = New-SetupFont 'Consolas' 8

$steam = (Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam' -ErrorAction SilentlyContinue).InstallPath
$gameDir = if ($steam) { Join-Path $steam 'steamapps\common\Gothic 3' } else { '' }

$form = New-Object Windows.Forms.Form
$form.Text = 'Myrtana Accord - Setup'
$form.ClientSize = New-Object Drawing.Size(760, 500)
$form.FormBorderStyle = 'FixedSingle'
$form.StartPosition = 'CenterScreen'
$form.BackColor = $cBg
$form.ForeColor = $cText
$form.Font = $fBody
$form.MaximizeBox = $false
$form.MinimizeBox = $true
$form.KeyPreview = $true

function New-Label([string]$text, [int]$x, [int]$y, [int]$w, [int]$h,
                   [Drawing.Font]$font = $fBody, [Drawing.Color]$color = $cText) {
    $label = New-Object Windows.Forms.Label
    $label.Text = $text
    $label.Location = "$x,$y"
    $label.Size = New-Object Drawing.Size($w, $h)
    $label.Font = $font
    $label.ForeColor = $color
    $label.BackColor = [Drawing.Color]::Transparent
    return $label
}

function New-Button([string]$text, [int]$x, [int]$y, [int]$w, [int]$h,
                    [Drawing.Color]$background, [Drawing.Color]$hover) {
    $button = New-Object Windows.Forms.Button
    $button.Text = $text
    $button.Location = "$x,$y"
    $button.Size = New-Object Drawing.Size($w, $h)
    $button.Font = $fButton
    $button.FlatStyle = 'Flat'
    $button.FlatAppearance.BorderSize = 0
    $button.BackColor = $background
    $button.ForeColor = $cText
    $button.Cursor = 'Hand'
    $button.Tag = @($background, $hover)
    $button.Add_MouseEnter({ $this.BackColor = $this.Tag[1] })
    $button.Add_MouseLeave({ $this.BackColor = $this.Tag[0] })
    return $button
}

function New-Card([string]$title, [string]$body, [int]$x, [int]$y) {
    $card = New-Object Windows.Forms.Panel
    $card.Location = "$x,$y"
    $card.Size = New-Object Drawing.Size(344, 104)
    $card.BackColor = $cCard
    $card.Controls.Add((New-Label $title 18 15 308 26 $fHeading $cText))
    $card.Controls.Add((New-Label $body 18 45 308 48 $fBody $cMuted))
    return $card
}

$title = New-Label 'MYRTANA ACCORD' 24 14 410 34 $fTitle $cText
$subtitle = New-Label 'Cooperative Mode for Gothic 3  |  v0.35.0-beta.1' 26 49 420 22 $fBody $cAccent
$credit = New-Label "by Yevh`nyevhsec1@gmail.com" 480 18 256 48 $fBody $cMuted
$credit.TextAlign = [Drawing.ContentAlignment]::MiddleRight
$form.Controls.AddRange(@($title, $subtitle, $credit))

$setupPanel = New-Object Windows.Forms.Panel
$setupPanel.Location = '24,86'
$setupPanel.Size = New-Object Drawing.Size(712, 324)
$setupPanel.BackColor = $cBg

$pathCard = New-Object Windows.Forms.Panel
$pathCard.Location = '0,0'
$pathCard.Size = New-Object Drawing.Size(712, 66)
$pathCard.BackColor = $cCard
$pathCard.Controls.Add((New-Label 'GOTHIC 3 FOLDER' 18 10 180 18 $fSmall $cMuted))
$pathText = New-Label $(if ($gameDir) { $gameDir } else { 'Choose your Gothic 3 folder' }) 18 31 552 24 $fBody $cText
$pathText.AutoEllipsis = $true
$pathText.AccessibleName = 'Gothic 3 folder'
$pathCard.Controls.Add($pathText)
$browse = New-Button '&Browse' 586 13 108 40 $cCardHi ([Drawing.Color]::FromArgb(56, 62, 68))
$browse.AccessibleName = 'Choose Gothic 3 folder'
$browse.TabIndex = 0
$pathCard.Controls.Add($browse)
$setupPanel.Controls.Add($pathCard)

$gameCard = New-Card 'Game support' 'Checks Gothic 3 and gets the supported patches from their official sources.' 0 82
$coopCard = New-Card 'Cooperative mode' 'Installs Myrtana Accord, the session server, and a desktop launcher.' 368 82
$setupPanel.Controls.AddRange(@($gameCard, $coopCard))

$internetCard = New-Object Windows.Forms.Panel
$internetCard.Location = '0,202'
$internetCard.Size = New-Object Drawing.Size(344, 92)
$internetCard.BackColor = $cCard
$vpnCheck = New-Object Windows.Forms.CheckBox
$vpnCheck.Text = '&Internet play'
$vpnCheck.Checked = $true
$vpnCheck.Location = '16,12'
$vpnCheck.Size = New-Object Drawing.Size(310,28)
$vpnCheck.Font = $fHeading
$vpnCheck.ForeColor = $cText
$vpnCheck.FlatStyle = 'Flat'
$vpnCheck.TabIndex = 1
$internetCard.Controls.Add($vpnCheck)
$internetCard.Controls.Add((New-Label 'Install Tailscale when no VPN is found.' 18 46 308 28 $fBody $cMuted))

$graphicsCard = New-Object Windows.Forms.Panel
$graphicsCard.Location = '368,202'
$graphicsCard.Size = New-Object Drawing.Size(344, 92)
$graphicsCard.BackColor = $cCard
$gfxCheck = New-Object Windows.Forms.CheckBox
$gfxCheck.Text = '&Graphics preset'
$gfxCheck.Checked = $true
$gfxCheck.Location = '16,12'
$gfxCheck.Size = New-Object Drawing.Size(310,28)
$gfxCheck.Font = $fHeading
$gfxCheck.ForeColor = $cText
$gfxCheck.FlatStyle = 'Flat'
$gfxCheck.TabIndex = 2
$graphicsCard.Controls.Add($gfxCheck)
$graphicsCard.Controls.Add((New-Label 'Use higher draw distances. You can undo it later.' 18 46 308 28 $fBody $cMuted))
$setupPanel.Controls.AddRange(@($internetCard, $graphicsCard))

$languageLabel = New-Label 'MOD LANGUAGE' 2 304 120 18 $fSmall $cMuted
$langBox = New-Object Windows.Forms.ComboBox
$languages = @(
    [pscustomobject]@{ Code = 'en'; Label = 'English' },
    [pscustomobject]@{ Code = 'ru'; Label = 'Russian' },
    [pscustomobject]@{ Code = 'de'; Label = 'German' },
    [pscustomobject]@{ Code = 'pl'; Label = 'Polish' },
    [pscustomobject]@{ Code = 'fr'; Label = 'French' },
    [pscustomobject]@{ Code = 'it'; Label = 'Italian' },
    [pscustomobject]@{ Code = 'es'; Label = 'Spanish' }
)
$langBox.DisplayMember = 'Label'
foreach ($language in $languages) { [void]$langBox.Items.Add($language) }
$langBox.SelectedIndex = 0
$langBox.Location = '124,298'
$langBox.Size = New-Object Drawing.Size(174, 30)
$langBox.DropDownStyle = 'DropDownList'
$langBox.FlatStyle = 'Flat'
$langBox.BackColor = $cCard
$langBox.ForeColor = $cText
$langBox.Font = $fBody
$langBox.TabIndex = 3
$setupPanel.Controls.AddRange(@($languageLabel, $langBox))
$form.Controls.Add($setupPanel)

$logPanel = New-Object Windows.Forms.Panel
$logPanel.Location = '24,86'
$logPanel.Size = New-Object Drawing.Size(712, 324)
$logPanel.BackColor = $cCard
$logTitle = New-Label 'INSTALL DETAILS' 16 12 220 20 $fSmall $cMuted
$log = New-Object Windows.Forms.TextBox
$log.Multiline = $true
$log.ScrollBars = 'Vertical'
$log.ReadOnly = $true
$log.Location = '16,42'
$log.Size = New-Object Drawing.Size(680, 264)
$log.BackColor = [Drawing.Color]::FromArgb(12, 12, 14)
$log.ForeColor = $cGood
$log.BorderStyle = 'None'
$log.Font = $fLog
$log.AccessibleName = 'Install details'
$logPanel.Controls.AddRange(@($logTitle, $log))
$logPanel.Visible = $false
$form.Controls.Add($logPanel)

$status = New-Label 'Ready to install.' 24 416 324 26 $fBody $cMuted
$status.AccessibleName = 'Setup status'
$form.Controls.Add($status)

$details = New-Button '&Details' 24 448 112 38 $cCard $cCardHi
$details.TabIndex = 4
$cancel = New-Button '&Cancel' 148 448 112 38 $cCard $cCardHi
$cancel.TabIndex = 5
$go = New-Button '&Install Myrtana Accord' 470 448 266 38 $cAccent $cAccentHi
$go.ForeColor = [Drawing.Color]::FromArgb(30, 25, 18)
$go.TabIndex = 6
$form.Controls.AddRange(@($details, $cancel, $go))
$form.AcceptButton = $go
$form.CancelButton = $cancel

$showDetails = $false
$details.Add_Click({
    $script:showDetails = -not $script:showDetails
    $setupPanel.Visible = -not $script:showDetails
    $logPanel.Visible = $script:showDetails
    $details.Text = if ($script:showDetails) { '&Setup' } else { '&Details' }
})

$browse.Add_Click({
    $picker = New-Object Windows.Forms.FolderBrowserDialog
    $picker.Description = 'Choose the folder that contains Gothic3.exe'
    $picker.ShowNewFolderButton = $false
    if ($gameDir -and (Test-Path $gameDir -PathType Container)) { $picker.SelectedPath = $gameDir }
    if ($picker.ShowDialog($form) -eq [Windows.Forms.DialogResult]::OK) {
        $script:gameDir = $picker.SelectedPath
        $pathText.Text = $script:gameDir
        if (Test-Path (Join-Path $script:gameDir 'Gothic3.exe') -PathType Leaf) {
            $pathText.ForeColor = $cText
            $status.Text = 'Gothic 3 folder found.'
            $status.ForeColor = $cGood
        } else {
            $pathText.ForeColor = $cBad
            $status.Text = 'Gothic3.exe was not found in this folder.'
            $status.ForeColor = $cBad
        }
    }
    $picker.Dispose()
})

$cancel.Add_Click({ $form.Close() })

$go.Add_Click({
    if (-not $gameDir -or -not (Test-Path (Join-Path $gameDir 'Gothic3.exe') -PathType Leaf)) {
        $status.Text = 'Choose the Gothic 3 folder first.'
        $status.ForeColor = $cBad
        return
    }
    $go.Enabled = $false
    $browse.Enabled = $false
    $vpnCheck.Enabled = $false
    $gfxCheck.Enabled = $false
    $langBox.Enabled = $false
    $script:showDetails = $true
    $setupPanel.Visible = $false
    $logPanel.Visible = $true
    $details.Text = '&Setup'
    $status.Text = 'Installing Myrtana Accord...'
    $status.ForeColor = $cAccent
    $log.AppendText("Starting setup...`r`n")

    $setupLog = Join-Path $env:TEMP 'g3coop_setup_gui.log'
    Remove-Item $setupLog -Force -ErrorAction SilentlyContinue
    $setupScript = Join-Path $PSScriptRoot 'setup_all_in_one.ps1'
    $safeScript = $setupScript.Replace("'", "''")
    $safeGameDir = $gameDir.Replace("'", "''")
    $language = $langBox.SelectedItem.Code
    $command = "& '$safeScript' -GameDir '$safeGameDir' -Language $language"
    if (-not $vpnCheck.Checked) { $command += ' -SkipVpn' }
    if (-not $gfxCheck.Checked) { $command += ' -SkipGraphics' }
    $command += " *> '$setupLog'"
    $childArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', $command)
    $proc = Start-Process 'powershell.exe' -ArgumentList $childArgs -WindowStyle Hidden -PassThru
    $shown = 0
    while (-not $proc.HasExited) {
        if (Test-Path $setupLog) {
            $content = @(Get-Content $setupLog -ErrorAction SilentlyContinue)
            if ($content.Count -gt $shown) {
                ($content | Select-Object -Skip $shown) | ForEach-Object { $log.AppendText($_ + "`r`n") }
                $shown = $content.Count
            }
        }
        [Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 250
    }
    if (Test-Path $setupLog) {
        $content = @(Get-Content $setupLog -ErrorAction SilentlyContinue)
        if ($content.Count -gt $shown) {
            ($content | Select-Object -Skip $shown) | ForEach-Object { $log.AppendText($_ + "`r`n") }
        }
    }
    if ($proc.ExitCode -eq 0) {
        $status.Text = 'Installed. Open Myrtana Accord from the desktop.'
        $status.ForeColor = $cGood
        $go.Text = 'Installed'
        $cancel.Text = '&Close'
    } else {
        $status.Text = "Setup failed. Exit code $($proc.ExitCode)."
        $status.ForeColor = $cBad
        $log.AppendText("`r`nFull log: $setupLog")
        $go.Enabled = $true
        $browse.Enabled = $true
        $vpnCheck.Enabled = $true
        $gfxCheck.Enabled = $true
        $langBox.Enabled = $true
    }
})

$form.Add_FormClosed({
    foreach ($font in @($fTitle, $fHeading, $fBody, $fSmall, $fButton, $fLog)) { $font.Dispose() }
})
[void]$form.ShowDialog()
