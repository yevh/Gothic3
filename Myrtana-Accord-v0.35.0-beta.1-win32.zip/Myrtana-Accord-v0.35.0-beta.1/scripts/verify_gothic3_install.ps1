param(
    [Parameter(Mandatory=$true)] [string] $GameDir
)

$ErrorActionPreference = "Stop"
$failed = $false

function Ok($m) { Write-Host "[OK]   $m" -ForegroundColor Green }
function Warn($m) { Write-Host "[WARN] $m" -ForegroundColor Yellow }
function Fail($m) { Write-Host "[FAIL] $m" -ForegroundColor Red; $script:failed = $true }

if (!(Test-Path $GameDir)) { Fail "GameDir not found: $GameDir"; exit 1 }
$GameDir = (Resolve-Path $GameDir).Path
Ok "GameDir exists: $GameDir"

$Exe = Join-Path $GameDir "Gothic3.exe"
if (Test-Path $Exe) {
    Ok "Found Gothic3.exe"
    $bytes = [System.IO.File]::ReadAllBytes($Exe)
    if ($bytes.Length -gt 0x100) {
        $peOffset = [BitConverter]::ToInt32($bytes, 0x3C)
        if ($peOffset -gt 0 -and $peOffset + 6 -lt $bytes.Length) {
            $machine = [BitConverter]::ToUInt16($bytes, $peOffset + 4)
            if ($machine -eq 0x14c) { Ok "Gothic3.exe appears to be PE32/x86" }
            else { Warn ("Unexpected PE machine value: 0x{0:X}" -f $machine) }
        }
    }
} else {
    Fail "Gothic3.exe not found"
}

$Scripts = Join-Path $GameDir "scripts"
$Ini = Join-Path $GameDir "Ini"
if (Test-Path $Scripts) { Ok "scripts directory exists" } else { Warn "scripts directory missing; installer will create it" }
if (Test-Path $Ini) { Ok "Ini directory exists" } else { Warn "Ini directory missing; installer will create it" }

$Dll = Join-Path $Scripts "Script_G3Coop.dll"
$Cfg = Join-Path $Ini "g3coop.ini"
$Log = Join-Path $GameDir "g3coop.log"
$Server = Join-Path $GameDir "g3coop_server.exe"

if (Test-Path $Dll) { Ok "Script_G3Coop.dll installed" } else { Warn "Script_G3Coop.dll is not installed yet" }
if (Test-Path $Cfg) { Ok "g3coop.ini installed" } else { Warn "g3coop.ini is not installed yet" }
if (Test-Path $Server) { Ok "g3coop_server.exe installed" } else { Warn "g3coop_server.exe is not installed yet" }
if (Test-Path $Log) { Ok "g3coop.log exists; check it after launch" } else { Warn "g3coop.log not found yet; this is normal before first launch" }

$CommonPatchMarkers = @(
    "CP_Changelog.txt",
    "Community Patch.txt",
    "Data\Projects_compiled.p00",
    "Data\Projects_compiled.pak"
)
$foundMarker = $false
foreach ($m in $CommonPatchMarkers) {
    if (Test-Path (Join-Path $GameDir $m)) { $foundMarker = $true; break }
}
if ($foundMarker) { Ok "Some Gothic 3 data/patch markers found" }
else { Warn "Could not prove Community Patch/patch stack from simple file markers. Verify manually." }

if ($failed) { exit 1 }
Write-Host "Verification finished. Warnings may still require manual checking." -ForegroundColor Cyan
