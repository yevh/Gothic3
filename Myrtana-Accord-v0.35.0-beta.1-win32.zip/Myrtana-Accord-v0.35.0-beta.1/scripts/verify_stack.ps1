# Verifies the installed Gothic 3 patch stack against config/stack_manifest.txt
# (docs/PATCH_STACK_RESEARCH.md item 5: pin the stack, verify the stack).
# Exit code 0 = all pinned files match; 1 = any mismatch/missing.

param([Parameter(Mandatory=$true)] [string] $GameDir)

$ErrorActionPreference = "Stop"
$manifest = Join-Path $PSScriptRoot "..\config\stack_manifest.txt"
if (!(Test-Path $manifest)) { throw "config/stack_manifest.txt not found" }

$failures = 0
foreach ($line in Get-Content $manifest) {
    if ($line -notmatch "^([^#|]+)\|([^|]+)\|\s*([0-9A-Fa-f]{64})\s*$") { continue }
    $file = $Matches[1].Trim().Replace("/", "\")
    $expected = $Matches[3].ToUpper()
    $path = Join-Path $GameDir $file
    if (!(Test-Path $path)) {
        Write-Host "[FAIL] missing: $file" -ForegroundColor Red; $failures++; continue
    }
    $actual = (Get-FileHash $path -Algorithm SHA256).Hash
    if ($actual -eq $expected) {
        Write-Host "[OK]   $file"
    } else {
        Write-Host "[FAIL] hash mismatch: $file" -ForegroundColor Red
        Write-Host "       expected $expected"
        Write-Host "       actual   $actual"
        $failures++
    }
}
if ($failures -eq 0) { Write-Host "Stack verified: matches pinned manifest." -ForegroundColor Green; exit 0 }
Write-Host "$failures file(s) differ from the pinned stack (CP 1.75.14 + PUP 1.1.1)." -ForegroundColor Red
exit 1
