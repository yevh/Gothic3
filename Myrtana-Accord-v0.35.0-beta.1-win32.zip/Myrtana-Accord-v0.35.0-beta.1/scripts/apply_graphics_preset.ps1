# Applies the docs/GRAPHICS_AND_QOL.md "ini modernization" step: raises the
# 2006-era draw distances to values sane for modern hardware. Creates
# ge3.INI.g3coop-backup next to the original on first run; -Restore puts the
# backup back. Values stay well under the engine maxima documented inside
# ge3.INI itself (FarClippingPlane max 50000).
#
# Resolution / FXAA / shadow quality / color grading: on the Steam + CP
# 1.75.14 layout these are NOT in reachable ini files - set them once in
# game Options -> Video (they are CP additions and persist per user).
#
# DXVK/ReShade: not applied here - scripts/install_dxvk.ps1 fetches the
# official DXVK release on real Vulkan-capable hardware (not VMs); ReShade
# must be installed manually from reshade.me (license forbids bundling).

param(
    [Parameter(Mandatory=$true)] [string] $GameDir,
    [switch] $Restore
)

$ErrorActionPreference = "Stop"
$ini = Join-Path $GameDir "Ini\ge3.INI"
$backup = "$ini.g3coop-backup"
if (!(Test-Path $ini)) { throw "ge3.INI not found under $GameDir" }

if ($Restore) {
    if (!(Test-Path $backup)) { throw "No backup at $backup" }
    Copy-Item $backup $ini -Force
    Write-Host "Restored original ge3.INI from backup."
    exit 0
}

if (!(Test-Path $backup)) { Copy-Item $ini $backup }

$settings = @{
    # 2x the 2006 defaults; max is 50000. Moderate on purpose - raise
    # further on strong hardware.
    "DistanceHigh.fFarClippingPlane_High"   = "20000.0"
    "DistanceHigh.fFarClippingPlane_Medium" = "15000.0"
    "DistanceHigh.fFarClippingPlane_Low"    = "10000.0"
}

$lines = Get-Content $ini
$applied = @()
foreach ($key in $settings.Keys) {
    $pattern = "^" + [regex]::Escape($key) + "="
    $replaced = $false
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match $pattern) {
            $lines[$i] = "$key=$($settings[$key])"
            $replaced = $true
            break
        }
    }
    if ($replaced) { $applied += $key }
    else { Write-Warning "$key not found in ge3.INI; skipped (patch layout changed?)" }
}
Set-Content -Path $ini -Value $lines
Write-Host "Applied $($applied.Count)/$($settings.Count) settings. Backup: $backup"
Write-Host "Delete Documents\gothic3\Shader.Cache after shader-affecting changes."
