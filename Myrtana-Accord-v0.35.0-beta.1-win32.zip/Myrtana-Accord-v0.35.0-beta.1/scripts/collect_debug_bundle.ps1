param(
    [Parameter(Mandatory=$true)] [string] $GameDir,
    [string] $OutDir = "g3coop_debug_bundle"
)

$ErrorActionPreference = 'Stop'
$GameDir = (Resolve-Path $GameDir).Path
$Out = if ([IO.Path]::IsPathRooted($OutDir)) { $OutDir } else { Join-Path (Get-Location) $OutDir }
New-Item -ItemType Directory -Force $Out | Out-Null
$Collected = [Collections.Generic.List[string]]::new()

function Export-BoundedText([string]$Source, [string]$Name, [int]$LimitBytes) {
    if (!(Test-Path $Source -PathType Leaf)) { return }
    if ($Name -eq 'g3coop.ini' -and (Get-Item $Source).Length -gt $LimitBytes) {
        $Destination = Join-Path $Out $Name
        '[Configuration omitted: exceeds 128 KiB export limit]' | Set-Content $Destination
        $Collected.Add($Destination)
        return
    }
    # Open an active log without requiring the game to release its write handle.
    $Stream = [IO.File]::Open($Source, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
    try {
        $Offset = [Math]::Max(0, $Stream.Length - $LimitBytes)
        $null = $Stream.Seek($Offset, [IO.SeekOrigin]::Begin)
        $Reader = [IO.StreamReader]::new($Stream, [Text.Encoding]::UTF8, $true)
        try {
            if ($Offset -gt 0) { $null = $Reader.ReadLine() } # omit partial first line
            # Bound the read even if a running game continues appending.
            $Buffer = New-Object char[] $LimitBytes
            $Count = $Reader.ReadBlock($Buffer, 0, $Buffer.Length)
            $Text = [string]::new($Buffer, 0, $Count)
        } finally { $Reader.Dispose() }
    } finally { $Stream.Dispose() }
    $Text = $Text -replace '(?im)^(\s*(?:password|session_password|session_token|token|player_guid)\s*=\s*).*$', '$1[redacted]'
    $Destination = Join-Path $Out $Name
    $Encoded = [Text.UTF8Encoding]::new($false).GetBytes($Text)
    if ($Encoded.Length -gt $LimitBytes) {
        $Start = $Encoded.Length - $LimitBytes
        while ($Start -lt $Encoded.Length -and ($Encoded[$Start] -band 0xC0) -eq 0x80) { ++$Start }
        $Bounded = New-Object byte[] ($Encoded.Length - $Start)
        [Array]::Copy($Encoded, $Start, $Bounded, 0, $Bounded.Length)
        $Encoded = $Bounded
    }
    [IO.File]::WriteAllBytes($Destination, $Encoded)
    $Collected.Add($Destination)
}

Export-BoundedText (Join-Path $GameDir 'g3coop.log') 'g3coop.log' (4MB)
Export-BoundedText (Join-Path $GameDir 'Ini\g3coop.ini') 'g3coop.ini' (128KB)
Export-BoundedText (Join-Path $env:USERPROFILE 'Documents\Gothic3\Lastlog_GE3.log') 'Lastlog_GE3.log' (4MB)
$Metadata = Join-Path $Out 'environment.txt'
$Lines = @('G3Coop debug bundle', "Date: $(Get-Date -Format o)", "OS: $([Environment]::OSVersion.VersionString)",
    'Log exports contain bounded tails. Configuration credentials and player GUID are redacted.')
$Dll = Join-Path $GameDir 'scripts\Script_G3Coop.dll'
if (Test-Path $Dll) { $Lines += "Script_G3Coop SHA256: $((Get-FileHash $Dll).Hash)" }
$Lines | Set-Content $Metadata
$Collected.Add($Metadata)
# Explicit inventory excludes unrelated files left in a reused output directory.
Compress-Archive -LiteralPath $Collected.ToArray() -DestinationPath "$Out.zip" -Force
Write-Host "Bundle written: $Out.zip" -ForegroundColor Green
