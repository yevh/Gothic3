# Windows PowerShell 5 compatible. Keep each argument intact, including empty
# passwords and campaign paths with spaces; Start-Process joins ArgumentList.
function ConvertTo-CampaignArgument([AllowEmptyString()][string]$Value) {
    $result = '"'; $slashes = 0
    foreach ($character in $Value.ToCharArray()) {
        if ($character -eq '\') { $slashes++; continue }
        if ($character -eq '"') { $result += ('\' * (2 * $slashes + 1)) + '"' }
        else { $result += ('\' * $slashes) + $character }
        $slashes = 0
    }
    return $result + ('\' * (2 * $slashes)) + '"'
}

function Start-CampaignServer {
    param(
        [Parameter(Mandatory=$true)][string]$GameDir,
        [ValidateRange(1,65535)][int]$Port = 33123,
        [AllowEmptyString()][string]$Password = '',
        [string]$CampaignPath = '',
        [string]$QuestPolicyPath = '',
        [ValidateSet('Working','New','Continue')][string]$Mode = 'Working'
    )
    $executable = [IO.Path]::GetFullPath((Join-Path $GameDir 'g3coop_server.exe'))
    if (-not (Test-Path $executable -PathType Leaf)) { throw 'g3coop_server.exe missing - reinstall.' }
    if (-not $CampaignPath) { $CampaignPath = Join-Path $GameDir 'CoopSaves\campaign.g3coop' }
    $CampaignPath = [IO.Path]::GetFullPath($CampaignPath).ToUpperInvariant()
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($CampaignPath))
    $values=@([string]$Port, '6', $Password, $CampaignPath, $QuestPolicyPath)
    if($Mode -ne 'Working') { $values+=@('100','--'+$Mode.ToLowerInvariant()) }
    $arguments = ($values |
        ForEach-Object { ConvertTo-CampaignArgument $_ }) -join ' '
    $matching = @(Get-CimInstance Win32_Process -Filter "Name='g3coop_server.exe'" | Where-Object {
        $_.ExecutablePath -and [IO.Path]::GetFullPath($_.ExecutablePath) -eq $executable -and
        $_.CommandLine.TrimEnd().EndsWith(' ' + $arguments, [StringComparison]::Ordinal)
    })
    if ($matching.Count -gt 1) { throw 'Multiple matching campaign servers require inspection.' }
    if ($matching.Count -eq 1) { $process = Get-Process -Id $matching[0].ProcessId -ErrorAction Stop }
    else { $process = Start-Process $executable -ArgumentList $arguments -WorkingDirectory $GameDir -WindowStyle Minimized -PassThru }
    $deadline = [DateTime]::UtcNow.AddSeconds(10)
    do {
        $process.Refresh()
        if ($process.HasExited) { throw "Campaign server refused startup (exit $($process.ExitCode)); check the campaign and port." }
        # The server binds only after validating and committing its checkpoint.
        $endpoint = Get-NetUDPEndpoint -LocalPort $Port -ErrorAction SilentlyContinue |
            Where-Object { $_.OwningProcess -eq $process.Id }
        if ($endpoint) { return $process }
        Start-Sleep -Milliseconds 100
    } while ([DateTime]::UtcNow -lt $deadline)
    throw 'Campaign server has not become ready; retry after checking its window.'
}
