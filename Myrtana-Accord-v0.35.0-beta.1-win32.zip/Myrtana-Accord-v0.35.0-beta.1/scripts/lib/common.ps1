# Shared helpers for the g3coop scripts. Dot-source:
#   . (Join-Path $PSScriptRoot "lib\common.ps1")

function Step($name) { Write-Host "`n=== $name ===" -ForegroundColor Cyan }
function Ok($msg)    { Write-Host "[OK]   $msg" }
function Warn($msg)  { Write-Host "[WARN] $msg" -ForegroundColor Yellow }
function Fail($msg)  { Write-Host "[FAIL] $msg" -ForegroundColor Red }

# Download with hard failure on HTTP errors and optional pinned hash.
function Get-VerifiedDownload([string]$Url, [string]$Dest, [string]$Sha256 = "") {
    curl.exe -fsSL -o $Dest $Url
    if ($LASTEXITCODE -ne 0) { throw "download failed (curl exit $LASTEXITCODE): $Url" }
    if ($Sha256) {
        $actual = (Get-FileHash $Dest -Algorithm SHA256).Hash
        if ($actual -ne $Sha256.ToUpper()) { throw "hash mismatch for $Dest" }
    }
}

# Rewrite only the keys we own; everything else (incl. player_guid) is kept.
# @() guard matters: one surviving line degrades to a string and += would
# concatenate instead of appending.
function Set-IniKeys([string]$Path, [hashtable]$Values) {
    $Path=$ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Path)
    $pattern = "^\s*(" + (($Values.Keys | ForEach-Object {[regex]::Escape($_)}) -join "|") + ")\s*="
    $lines = @()
    if (Test-Path $Path) { $lines = @([IO.File]::ReadAllLines($Path) | Where-Object { $_ -notmatch $pattern }) }
    foreach ($key in $Values.Keys) { $lines += "$key = $($Values[$key])" }
    $temporary=$Path+'.profile-'+[guid]::NewGuid().ToString('N')+'.tmp'
    try {
        [IO.File]::WriteAllLines($temporary,[string[]]$lines,(New-Object Text.UTF8Encoding($false)))
        if(Test-Path $Path){[IO.File]::Replace($temporary,$Path,[NullString]::Value)}
        else {[IO.File]::Move($temporary,$Path)}
    } finally {if(Test-Path $temporary){Remove-Item -LiteralPath $temporary}}
}

function Read-IniValue([string]$Path, [string]$Key, [string]$Default) {
    if (Test-Path $Path) {
        $m = Select-String -Path $Path -Encoding UTF8 -Pattern "^\s*$([regex]::Escape($Key))\s*=\s*`"?([^`"\r\n]*)`"?" |
            Select-Object -Last 1
        if ($m) { return $m.Matches[0].Groups[1].Value.Trim() }
    }
    return $Default
}

function Parse-HostPort([string]$Text, [string]$DefaultPort = "33123") {
    $parts = $Text.Split(":")
    $addr = $parts[0].Trim()
    $port = if ($parts.Count -gt 1 -and $parts[1].Trim()) { $parts[1].Trim() } else { $DefaultPort }
    return @($addr, $port)
}

function Copy-LangCatalogs([string]$RepoRoot, [string]$IniDir) {
    $langDir = Join-Path $RepoRoot "config\lang"
    if (Test-Path $langDir) {
        Get-ChildItem $langDir -Filter "g3coop_lang_*.ini" |
            ForEach-Object { Copy-Item $_.FullName (Join-Path $IniDir $_.Name) -Force }
    }
}
