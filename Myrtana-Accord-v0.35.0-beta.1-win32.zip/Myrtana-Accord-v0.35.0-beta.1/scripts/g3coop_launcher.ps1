# Myrtana Accord launcher - host or join a co-op session in two clicks.
# Borderless dark UI; session logic matches the CLI tools.

param([Parameter(Mandatory=$true)] [string] $GameDir, [string] $CampaignPath = "")

. (Join-Path $PSScriptRoot "lib\common.ps1")
. (Join-Path $PSScriptRoot "lib\campaign_server.ps1")
Add-Type -AssemblyName System.Windows.Forms, System.Drawing | Out-Null
Add-Type -Name Native -Namespace G3 -MemberDefinition @'
[DllImport("gdi32.dll")]
public static extern IntPtr CreateRoundRectRgn(int l, int t, int r, int b, int w, int h);
[DllImport("user32.dll")]
public static extern bool ReleaseCapture();
[DllImport("gdi32.dll")]
public static extern bool DeleteObject(IntPtr hObject);
[DllImport("user32.dll")]
public static extern IntPtr SendMessage(IntPtr hWnd, int msg, int wParam, int lParam);
[DllImport("user32.dll")]
public static extern bool SetProcessDPIAware();
'@
# Render at real pixels on HiDPI displays - otherwise Windows bitmap-scales
# the window and clips the fixed layout.
[G3.Native]::SetProcessDPIAware() | Out-Null
[Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference = "Stop"
$GameDir=(Resolve-Path $GameDir).Path
$BrandName = 'Myrtana Accord'
$BrandVersion = '0.35.0-beta.1'
$BrandAuthor = 'Yevh'
$BrandContact = 'yevhsec1@gmail.com'
$BrandImagePath = Join-Path $PSScriptRoot 'assets\myrtana-accord-background.jpg'
if (!(Test-Path $BrandImagePath -PathType Leaf)) {
    $BrandImagePath = Join-Path $PSScriptRoot '..\assets\branding\myrtana-accord-background.jpg'
}

$ini = Join-Path $GameDir "Ini\g3coop.ini"
$curHost = Read-IniValue $ini "server_host" "127.0.0.1"
$curPort = Read-IniValue $ini "server_port" "33123"
$curName = Read-IniValue $ini "player_name" $env:USERNAME
$curFace = Read-IniValue $ini "character_face" "saved"
$curLang = Read-IniValue $ini "language" "en"
$curIsHost = Read-IniValue $ini 'is_host' (Read-IniValue $ini 'host_mode' (Read-IniValue $ini 'host' 'false'))

# ---- palette ---------------------------------------------------------------
$cBg      = [Drawing.Color]::FromArgb(18, 20, 23)
$cCard    = [Drawing.Color]::FromArgb(31, 35, 39)
$cCardHi  = [Drawing.Color]::FromArgb(43, 48, 53)
$cText    = [Drawing.Color]::FromArgb(235, 236, 240)
$cMuted   = [Drawing.Color]::FromArgb(168, 174, 181)
$cAccent  = [Drawing.Color]::FromArgb(210, 174, 108)
$cAccentH = [Drawing.Color]::FromArgb(232, 198, 135)
$cGood    = [Drawing.Color]::FromArgb(110, 231, 183)
$cBad     = [Drawing.Color]::FromArgb(248, 113, 113)

$fTitle  = New-Object Drawing.Font("Segoe UI", 16, [Drawing.FontStyle]::Bold)
$fLabel  = New-Object Drawing.Font("Segoe UI", 8, [Drawing.FontStyle]::Bold)
$fInput  = New-Object Drawing.Font("Segoe UI", 11)
$fSmall  = New-Object Drawing.Font("Segoe UI", 9)
$fButton = New-Object Drawing.Font("Segoe UI Semibold", 11)

$form = New-Object Windows.Forms.Form
$form.SuspendLayout()
$form.Text = "$BrandName - Cooperative Mode for Gothic 3"
$form.FormBorderStyle = "None"
$form.Size = New-Object Drawing.Size(720, 484)
$form.StartPosition = "CenterScreen"
$form.BackColor = $cBg
$form.MaximizeBox = $false
$setRegion = {
    $handle = [G3.Native]::CreateRoundRectRgn(0, 0, $form.Width, $form.Height, 18, 18)
    $oldRegion = $form.Region
    try { $form.Region = [Drawing.Region]::FromHrgn($handle) }
    finally { [G3.Native]::DeleteObject($handle) | Out-Null }
    if ($oldRegion) { $oldRegion.Dispose() }
}
$form.Add_Shown($setRegion)
$form.Add_Resize($setRegion)   # keep the rounded clip in sync if the OS rescales

# Draggable header strip.
$header = New-Object Windows.Forms.Panel
$header.Size = New-Object Drawing.Size(720, 80); $header.Location = "0,0"
$header.BackColor = $cBg
if (Test-Path $BrandImagePath -PathType Leaf) {
    $brandImage = [Drawing.Image]::FromFile($BrandImagePath)
    $header.BackgroundImage = $brandImage
    $header.BackgroundImageLayout = [Windows.Forms.ImageLayout]::Zoom
}
$header.Add_MouseDown({ [G3.Native]::ReleaseCapture() | Out-Null
                        [G3.Native]::SendMessage($form.Handle, 0xA1, 0x2, 0) | Out-Null })
$form.Controls.Add($header)

$dot = New-Object Windows.Forms.Label
$dot.Text = [string][char]0x25CF; $dot.ForeColor = $cAccent
$dot.Font = New-Object Drawing.Font("Segoe UI", 11)
$dot.BackColor = [Drawing.Color]::Transparent
$dot.Location = "28,22"; $dot.AutoSize = $true
$header.Controls.Add($dot)

$title = New-Object Windows.Forms.Label
$title.Text = $BrandName.ToUpperInvariant()
$title.Font = $fTitle; $title.ForeColor = $cText
$title.BackColor = [Drawing.Color]::Transparent
$title.Location = "48,12"; $title.AutoSize = $true
$header.Controls.Add($title)
$subtitle=New-Object Windows.Forms.Label
$subtitle.Text="Cooperative Mode for Gothic 3  |  v$BrandVersion"; $subtitle.Font=$fSmall
$subtitle.ForeColor=$cMuted; $subtitle.Location="48,44"; $subtitle.AutoSize=$true
$subtitle.BackColor = [Drawing.Color]::Transparent
$header.Controls.Add($subtitle)

$credit = New-Object Windows.Forms.Label
$credit.Text = "by $BrandAuthor`n$BrandContact"
$credit.Font = $fSmall; $credit.ForeColor = $cText
$credit.BackColor = [Drawing.Color]::FromArgb(120, 18, 20, 23)
$credit.Location = "430,16"; $credit.Size = New-Object Drawing.Size(220,44)
$credit.TextAlign = [Drawing.ContentAlignment]::MiddleRight
$header.Controls.Add($credit)

$close = New-Object Windows.Forms.Label
$close.Text = [string][char]0x2715; $close.ForeColor = $cMuted
$close.Font = New-Object Drawing.Font("Segoe UI", 12)
$close.Location = "672,20"; $close.AutoSize = $true
$close.Cursor = "Hand"
$close.Add_Click({ $form.Close() })
$close.Add_MouseEnter({ $close.ForeColor = $cText })
$close.Add_MouseLeave({ $close.ForeColor = $cMuted })
$header.Controls.Add($close)

# ---- builders ---------------------------------------------------------------
function Add-Field([string]$label, [string]$value, [int]$y, [int]$w, [int]$x=28) {
    $lbl = New-Object Windows.Forms.Label
    $lbl.Text = $label.ToUpper(); $lbl.Font = $fLabel; $lbl.ForeColor = $cMuted
    $lbl.Location = "$($x+2),$y"; $lbl.AutoSize = $true
    $lbl.BackColor=[Drawing.Color]::FromArgb(24,27,31)
    $form.Controls.Add($lbl)

    $card = New-Object Windows.Forms.Panel
    $card.Location = "$x,$($y + 20)"; $card.Size = New-Object Drawing.Size($w, 40)
    $card.BackColor = $cCard
    $box = New-Object Windows.Forms.TextBox
    $box.Text = $value; $box.Font = $fInput
    $box.BackColor = $cCard; $box.ForeColor = $cText
    $box.BorderStyle = "None"
    $box.Location = "14,10"; $box.Width = $w - 28
    $card.Controls.Add($box)
    $form.Controls.Add($card)
    return $box
}

function Add-Button([string]$text, [int]$x, [int]$y, [int]$w, [int]$h,
                    [Drawing.Color]$bg, [Drawing.Color]$bgHover, [Drawing.Font]$font) {
    $b = New-Object Windows.Forms.Button
    $b.Text = $text; $b.Font = $font
    $b.Location = "$x,$y"; $b.Size = New-Object Drawing.Size($w, $h)
    $b.FlatStyle = "Flat"; $b.FlatAppearance.BorderSize = 0
    $b.BackColor = $bg; $b.ForeColor = $cText; $b.Cursor = "Hand"
    $b.Tag = @($bg, $bgHover)
    $b.Add_MouseEnter({ $this.BackColor = $this.Tag[1] })
    $b.Add_MouseLeave({ $this.BackColor = $this.Tag[0] })
    $form.Controls.Add($b)
    return $b
}

function Show-BrandSplash {
    if (!(Test-Path $BrandImagePath -PathType Leaf)) { return $null }
    $splash = New-Object Windows.Forms.Form
    $splash.FormBorderStyle = 'None'
    $splash.StartPosition = 'CenterScreen'
    $splash.Size = New-Object Drawing.Size(960,540)
    $splash.BackgroundImage = [Drawing.Image]::FromFile($BrandImagePath)
    $splash.BackgroundImageLayout = [Windows.Forms.ImageLayout]::Zoom
    $splash.BackColor = $cBg

    $splashTitle = New-Object Windows.Forms.Label
    $splashTitle.Text = $BrandName.ToUpperInvariant()
    $splashTitle.Font = New-Object Drawing.Font('Segoe UI Semibold',28)
    $splashTitle.ForeColor = $cText; $splashTitle.BackColor = [Drawing.Color]::Transparent
    $splashTitle.Location = '48,50'; $splashTitle.AutoSize = $true
    $splash.Controls.Add($splashTitle)

    $splashSubtitle = New-Object Windows.Forms.Label
    $splashSubtitle.Text = "Cooperative Mode for Gothic 3  |  v$BrandVersion"
    $splashSubtitle.Font = New-Object Drawing.Font('Segoe UI',13)
    $splashSubtitle.ForeColor = $cAccentH; $splashSubtitle.BackColor = [Drawing.Color]::Transparent
    $splashSubtitle.Location = '52,102'; $splashSubtitle.AutoSize = $true
    $splash.Controls.Add($splashSubtitle)

    $splashCredit = New-Object Windows.Forms.Label
    $splashCredit.Text = "by $BrandAuthor  |  $BrandContact"
    $splashCredit.Font = New-Object Drawing.Font('Segoe UI',11)
    $splashCredit.ForeColor = $cText; $splashCredit.BackColor = [Drawing.Color]::FromArgb(150,18,20,23)
    $splashCredit.Location = '48,470'; $splashCredit.Size = New-Object Drawing.Size(500,34)
    $splashCredit.TextAlign = [Drawing.ContentAlignment]::MiddleLeft
    $splash.Controls.Add($splashCredit)
    $splash.Add_FormClosed({ if ($this.BackgroundImage) { $this.BackgroundImage.Dispose() } })
    $splash.Show(); [Windows.Forms.Application]::DoEvents()
    return $splash
}

# Separate character and connection cards keep setup readable at a glance.
foreach($cardSpec in @(@(24,318),@(360,336))) {
    $panel=New-Object Windows.Forms.Panel
    $panel.Location="$($cardSpec[0]),90"; $panel.Size=New-Object Drawing.Size($cardSpec[1],270)
    $panel.BackColor=[Drawing.Color]::FromArgb(24,27,31)
    $form.Controls.Add($panel)
}
function Add-Heading([string]$text,[int]$x) {
    $label=New-Object Windows.Forms.Label
    $label.Text=$text; $label.Location="$x,108"; $label.AutoSize=$true
    $label.Font=New-Object Drawing.Font('Segoe UI Semibold',12)
    $label.ForeColor=$cText; $label.BackColor=[Drawing.Color]::FromArgb(24,27,31)
    $form.Controls.Add($label); $label.BringToFront()
}
Add-Heading 'Your character' 40
Add-Heading 'Your session' 376

$nameBox = Add-Field "Display name" $curName 146 286 40
$nameBox.Name='PlayerName'; $nameBox.AccessibleName='Player name'; $nameBox.TabIndex=0; $nameBox.Parent.TabIndex=0
$hostBox = Add-Field "Server address or join code" "${curHost}:${curPort}" 146 214 376
$hostBox.Name='ServerAddress'; $hostBox.AccessibleName='Server address or join code'; $hostBox.TabIndex=0; $hostBox.Parent.TabIndex=2
$testBtn = Add-Button "Test" 598 166 82 40 $cCard $cCardHi $fSmall
$testBtn.TabIndex=3

$modeBox = New-Object Windows.Forms.ComboBox
$modeBox.Name='CampaignMode'; $modeBox.AccessibleName='Campaign mode'
$modeBox.Items.AddRange(@('New campaign', 'Continue campaign', 'Join / rejoin friends'))
$modeBox.DropDownStyle='DropDownList'; $modeBox.FlatStyle='Flat'
$modeBox.Font=$fInput; $modeBox.BackColor=$cCard; $modeBox.ForeColor=$cText
$modeBox.Location='376,226'; $modeBox.Width=304; $modeBox.TabIndex=4
$existingCampaign=if($CampaignPath){$CampaignPath}else{Join-Path $GameDir 'CoopSaves\campaign.g3coop'}
$modeBox.SelectedIndex=if($curIsHost -match '^(true|1|yes|on)$'){if(Test-Path $existingCampaign -PathType Leaf){1}else{0}}else{2}
$form.Controls.Add($modeBox)

$langLbl = New-Object Windows.Forms.Label
$langLbl.Text="LANGUAGE"; $langLbl.Font=$fLabel; $langLbl.ForeColor=$cMuted
$langLbl.BackColor=[Drawing.Color]::FromArgb(24,27,31)
$langLbl.Location="378,270"; $langLbl.AutoSize=$true
$form.Controls.Add($langLbl)
$langBox = New-Object Windows.Forms.ComboBox
$langBox.Items.AddRange(@("en", "ru", "de", "pl", "fr", "it", "es"))
$langBox.SelectedItem=$curLang
if($null -eq $langBox.SelectedItem){$langBox.SelectedIndex=0}
$langBox.Font=$fInput; $langBox.DropDownStyle="DropDownList"; $langBox.FlatStyle="Flat"
$langBox.BackColor=$cCard; $langBox.ForeColor=$cText
$langBox.Location="376,294"; $langBox.Width=100; $langBox.TabIndex=5
$langBox.AccessibleName='Language'
$form.Controls.Add($langBox)
$ipBtn = Add-Button "My addresses" 490 288 190 38 $cCard $cCardHi $fSmall
$ipBtn.TabIndex=6

$faceLabel=New-Object Windows.Forms.Label
$faceLabel.Text="HERO LOOK"; $faceLabel.Font=$fLabel; $faceLabel.ForeColor=$cMuted
$faceLabel.BackColor=[Drawing.Color]::FromArgb(24,27,31)
$faceLabel.Location="42,222"; $faceLabel.AutoSize=$true; $form.Controls.Add($faceLabel)
$faceBox=New-Object Windows.Forms.ComboBox
$faceBox.Name='CharacterFace'; $faceBox.AccessibleName='Character face'
$faceBox.Location="40,246"; $faceBox.Width=286; $faceBox.Font=$fInput; $faceBox.TabIndex=1
$faceBox.DropDownStyle="DropDownList"; $faceBox.FlatStyle="Flat"
$faceBox.BackColor=$cCard; $faceBox.ForeColor=$cText
$faces=@(
    [pscustomobject]@{Id='saved';Label='Keep my saved face';Description='Keep the face stored in this save.'},
    [pscustomobject]@{Id='original';Label='Original hero face';Description='Use the original hero face.'},
    [pscustomobject]@{Id='diego';Label="Diego face";Description="Use Diego's face to look different from friends."},
    [pscustomobject]@{Id='gorn';Label="Gorn face";Description="Use Gorn's face to look different from friends."}
)
$faceBox.DisplayMember='Label'
foreach($face in $faces){[void]$faceBox.Items.Add($face)}
$faceBox.SelectedIndex=0
for($i=0;$i -lt $faces.Count;$i++){if($faces[$i].Id -eq $curFace){$faceBox.SelectedIndex=$i}}
$form.Controls.Add($faceBox)
$faceDescription=New-Object Windows.Forms.Label
$faceDescription.Location='40,290'; $faceDescription.Size=New-Object Drawing.Size(286,54)
$faceDescription.Font=$fSmall; $faceDescription.ForeColor=$cMuted
$faceDescription.BackColor=[Drawing.Color]::FromArgb(24,27,31)
$form.Controls.Add($faceDescription)
$updateDescription={
    if($faceBox.SelectedItem){$faceDescription.Text=$faceBox.SelectedItem.Description+"`nEach player can choose a different face."}
}
$faceBox.Add_SelectedIndexChanged($updateDescription)
& $updateDescription

$status = New-Object Windows.Forms.Label
$status.Location="24,376"; $status.Size=New-Object Drawing.Size(672,40)
$status.Font=$fSmall; $status.ForeColor=$cMuted
$status.Text="Choose your character and start, continue or rejoin a campaign."
$status.AccessibleName='Setup status'; $form.Controls.Add($status)

$cancel = Add-Button "Cancel" 24 424 92 42 $cCard $cCardHi $fSmall
$cancel.Name='CancelSetup'; $cancel.AccessibleName='Cancel setup'; $cancel.TabIndex=7
$cancel.DialogResult=[Windows.Forms.DialogResult]::Cancel
$cancel.Add_Click({$form.Close()}); $form.CancelButton=$cancel
$applyProfile = Add-Button "Save character" 128 424 214 42 $cCard $cCardHi $fSmall
$applyProfile.Name='ApplyCharacter'; $applyProfile.AccessibleName='Apply character settings'; $applyProfile.TabIndex=8
$play = Add-Button "Play co-op" 360 424 336 42 $cAccent $cAccentH $fButton
$updateMode={
    $play.Text=@('Start new campaign','Continue campaign','Join / rejoin')[$modeBox.SelectedIndex]
    $status.ForeColor=$cMuted
    $status.Text=@('Creates a new campaign. Choose New Game in Gothic 3 to begin.',
        'Restores the last complete party checkpoint and your saved character.',
        'Use the same character identity to return. A continued campaign restores your checkpoint automatically.')[$modeBox.SelectedIndex]
}
$modeBox.Add_SelectedIndexChanged($updateMode)
& $updateMode
$play.ForeColor=[Drawing.Color]::FromArgb(30,25,18); $play.TabIndex=9
# Panels are decorative; bring interactive controls above them without making them
# children of a second scaling container.
foreach($control in @($form.Controls)) {if($control -isnot [Windows.Forms.Panel]){$control.BringToFront()}}
foreach($control in @($form.Controls)) {if($control -is [Windows.Forms.Panel] -and $control.Controls.Count){$control.BringToFront()}}

# ---- behavior ----------------------------------------------------------------
function Get-CharacterProfileValues {
    $name=$nameBox.Text.Trim()
    if(!$name -or [Text.Encoding]::UTF8.GetByteCount($name) -gt 64 -or $name -match '[\x00-\x1f\x7f";#]') {
        throw 'Enter a shorter name without quotes, control characters, # or ;.'
    }
    if(!$faceBox.SelectedItem){throw 'Choose a character face.'}
    if(Get-Process Gothic3 -ErrorAction SilentlyContinue | Where-Object {$_.Path -eq (Join-Path $GameDir 'Gothic3.exe')}) {
        throw 'Close this game before applying character settings.'
    }
    return @{player_name='"'+$name+'"';character_face=$faceBox.SelectedItem.Id}
}
$applyProfile.Add_Click({
    try {
        Set-IniKeys $ini (Get-CharacterProfileValues)
        $status.ForeColor=$cGood; $status.Text='Character settings saved. They apply when you next load your character.'
    } catch {$status.ForeColor=$cBad;$status.Text=$_.Exception.Message}
})
$testBtn.Add_Click({
    $addr, $port = Parse-HostPort $hostBox.Text
    $ctl = Join-Path $GameDir "g3coopctl.exe"
    if (-not (Test-Path $ctl)) { $status.ForeColor = $cBad; $status.Text = "g3coopctl.exe missing - reinstall the mod."; return }
    $status.ForeColor = $cMuted; $status.Text = "Testing $addr`:$port ..."
    $testBtn.Enabled = $false
    [Windows.Forms.Application]::DoEvents()
    $out = (& $ctl probe $addr $port 2>&1 | Out-String).Trim()
    $status.ForeColor = if ($out -match "probe OK") { $cGood } else { $cBad }
    $status.Text = $out
    $testBtn.Enabled = $true
})

$ipBtn.Add_Click({
    $addresses = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $_.IPAddress -notmatch "^(127\.|169\.254)" } |
        ForEach-Object { $_.IPAddress }
    $status.ForeColor = $cMuted
    $status.Text = "Give friends one of these (VPN 100.x / 25.x for internet):`n" +
                   (($addresses | Select-Object -First 5) -join "    ")
})

$play.Add_Click({
    try {
        $profile=Get-CharacterProfileValues
        $gameExe=Join-Path $GameDir 'Gothic3.exe'
        if(!(Test-Path $gameExe -PathType Leaf)){throw 'Gothic3.exe is missing from the selected game folder.'}
        if ($hostBox.Text.Trim() -match "^G3-") {
            $ctl = Join-Path $GameDir "g3coopctl.exe"
            if (-not (Test-Path $ctl)) { $status.ForeColor = $cBad; $status.Text = "g3coopctl.exe missing - reinstall the mod."; return }
            Push-Location $GameDir
            $joinOut = & $ctl join $hostBox.Text.Trim() 2>&1 | Out-String
            Pop-Location
            if ($LASTEXITCODE -ne 0) { $status.ForeColor = $cBad; $status.Text = "Join code rejected: $($joinOut.Trim())"; return }
            # g3coopctl join writes to <GameDir>\g3coop.ini (cwd), not Ini\.
            $joinIni = Join-Path $GameDir "g3coop.ini"
            $resolvedHost = Read-IniValue $joinIni "server_host" ""
            $resolvedPort = Read-IniValue $joinIni "server_port" "33123"
            if ($resolvedHost) { $hostBox.Text = "${resolvedHost}:${resolvedPort}" }
        }
        $addr, $port = Parse-HostPort $hostBox.Text
        if (($modeBox.SelectedIndex -lt 2)) { $addr = "127.0.0.1" }

        Set-IniKeys $ini @{
            server_host = "`"$addr`""
            server_port = $port
            player_name = "`"$($nameBox.Text.Trim())`""
            character_face = $profile.character_face
            language    = "`"$($langBox.SelectedItem)`""
            is_host     = ([string]($modeBox.SelectedIndex -lt 2)).ToLowerInvariant()
            host        = ([string]($modeBox.SelectedIndex -lt 2)).ToLowerInvariant()
            host_mode   = ([string]($modeBox.SelectedIndex -lt 2)).ToLowerInvariant()
        }

        if (($modeBox.SelectedIndex -lt 2)) {
            $password = Read-IniValue $ini "session_token" (Read-IniValue $ini "password" "")
            $policy = Read-IniValue $ini "quest_policy_path" ""
            $selectedPath=$existingCampaign
            $mode=if($modeBox.SelectedIndex -eq 0){'New'}else{'Continue'}
            if($mode -eq 'New' -and (Test-Path $selectedPath)) {
                throw 'A campaign already exists here. Choose Continue, or launch setup with a separate CampaignPath for a new adventure.'
            }
            $serverProcess = Start-CampaignServer -GameDir $GameDir -Port $port -Password $password -CampaignPath $selectedPath -QuestPolicyPath $policy -Mode $mode
            $status.ForeColor = $cGood; $status.Text = "Campaign ready on port $port. Launching Gothic 3..."
        } else {
            $status.ForeColor = $cGood
            $status.Text = "Joining $addr`:$port as $($nameBox.Text.Trim()). Launching Gothic 3..."
        }
        $splash = Show-BrandSplash
        Start-Process -FilePath $gameExe -WorkingDirectory $GameDir
        if ($splash) {
            for ($frame=0; $frame -lt 15; $frame++) {
                [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 100
            }
            $splash.Close(); $splash.Dispose()
        }
        $form.Close()
    } catch { $status.ForeColor = $cBad; $status.Text = "Error: $_" }
})

$form.AutoScaleDimensions=New-Object Drawing.SizeF(96,96)
$form.AutoScaleMode=[Windows.Forms.AutoScaleMode]::Dpi
$form.ResumeLayout($false)
[void]$form.ShowDialog()
if ($brandImage) { $brandImage.Dispose() }
